@extends('front.layout')
@section('header')
Booking
@endsection
@section('content')

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
<link rel='stylesheet' href='https://eonasdan.github.io/bootstrap-datetimepicker/css/prettify-1.0.css'>
<link rel='stylesheet' href='https://eonasdan.github.io/bootstrap-datetimepicker/css/base.css'>
<link rel='stylesheet' href='https://cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/build/css/bootstrap-datetimepicker.css'>
<style type="text/css">
   .custom-slot-design-box ul {
   list-style: none;
   padding-left: 0px;
   }
   @media only screen and (max-width: 300px) {
   .custom-slot-design-box li {
   display: inline-block;
   width: 30%;
   float: right;
   margin-right: 6px;
   }
   }
   @media only screen and (min-width: 600px) {
   .custom-slot-design-box li {
       display: table;
    width: 59%;
    float: right;
    overflow: scroll;
    margin-right: 6px;
   }
   }
   .active {
   background: #af9d9e;
   color: white !important;
   border: 2px solid #af9d9e !important;
   }
   .sel_slot {
   background: #ff424c;
   color: white !important;
   }
   .appointment-time input {
   position: relative;
   width: 100%;
   height: 50px;
   background: var(--background-light);
   padding: 10px 20px;
   color: #808080;
   font-size: 14px;
   border-radius: 10px;
   }
   .custom-slot-design-box input {
   visibility: hidden;
   display: none;
   }
   input[type="radio"], input[type="checkbox"] {
   box-sizing: border-box;
   padding: 0;
   }
   .custom-slot-design-box label {
   cursor: pointer;
   padding: 13px;
   margin-bottom: 10px;
   font-size: 18px;
   border-radius: 10px;
   width: 100%;
   color: #05224f;
   border: 2px solid #f9cacc;
   }
   .card {
  background: #fff;
    border-radius: 2px;
    display: inline-block;
    height: 400px;
    margin: 1rem;
    position: relative;
    width: 100%;
    margin-top: 0px;
    padding-left: 0px;
    padding-right: 0px;
}
.card-header {
    padding: 0.75rem 1.25rem;
    margin-bottom: 0;
    background: #ff424c;
    color: white;
}
.card-1 {
  box-shadow: 6px 11px 24px 0 rgba(23,31,37,0.12);
  border: none;
  transition: all 0.3s cubic-bezier(.25,.8,.25,1);
  border-radius: 15px;
  padding: 15px;
}
input.razorpay-payment-button {
    background: #ff424c;
    border: none;
    border-radius: 8px;
    color: #fff;
}
input.razorpay-payment-button:hover {
    background: #ff424c;
}
input[type="text"], input[type="number"], input[type="date"], input[type="email"] {
    border: 1px solid #CED4D9;
}
input[type="text"]:focus, input[type="number"]:focus, input[type="date"]:focus, input[type="email"]:focus {
    border: 1px solid #FFE2DE;
    box-shadow:none;
}
::placeholder {
    color: #6C757;
}
input[type=date]:invalid::-webkit-datetime-edit {
    color: #6C757;
}
.field-note {
    font-size: 13px;
    margin-top: 4px;
}
.title-underline {
    border-color: rgb(255,226,222);
}

.title-underline, #wysiwyg-root .title-underline {
    display: block;
    width: 28px;
    border-bottom: 5px solid;
    margin-top: 20px;
    border-color: #ff424c;
}
h2,h4 {
    color: #0E2266;
}
.bootstrap-datetimepicker-widget {
  width: 100% !important;
  max-width: none !important;
} 


.select2-container .select2-selection--single {
    box-sizing: border-box;
    cursor: pointer;
    display: block;
    height: 37px !important;
    user-select: none;
    -webkit-user-select: none;
}

.select2-container--default .select2-selection--single .select2-selection__rendered {
    color: #444;
    line-height: 33px !important;
}

div.files {
  background: #eee;
  padding: 1rem;
  margin: 1rem 0;
  border-radius: 10px;
}
div.files ul {
  list-style: none;
  padding: 0;
  max-height: 150px;
  overflow: auto;
}
div.files ul li {
  padding: 0.5rem 0;
  padding-right: 2rem;
  position: relative;
}
div.files ul li i {
  cursor: pointer;
  position: absolute;
  top: 50%;
  right: 0;
  transform: translatey(-50%);
}
div.container {
  width: 100%;
  padding: 0 2rem;
}

span.file-size {
  color: #999;
  padding-left: 0.5rem;
}
@font-face{font-family:lora;font-style:normal;font-weight:400;src:local('Lora'),url(https://fonts.cdnfonts.com/s/13623/Lora.woff) format('woff')}@font-face{font-family:lora;font-style:normal;font-weight:400;src:local('Lora'),url(https://fonts.cdnfonts.com/s/13623/Lora-Regular.woff) format('woff')}@font-face{font-family:lora;font-style:italic;font-weight:400;src:local('Lora'),url(https://fonts.cdnfonts.com/s/13623/Lora-Italic.woff) format('woff')}@font-face{font-family:lora;font-style:normal;font-weight:700;src:local('Lora'),url(https://fonts.cdnfonts.com/s/13623/Lora-Bold.woff) format('woff')}@font-face{font-family:lora;font-style:italic;font-weight:700;src:local('Lora'),url(https://fonts.cdnfonts.com/s/13623/Lora-BoldItalic.woff) format('woff')}
</style>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />


<section class="elementor-section elementor-top-section elementor-element elementor-element-2bf47c1a elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2bf47c1a" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" style="font-family: 'lora', sans-serif;">
   <div class="container" >
      <div class="row" style="margin: 80px 0px;">
            <div class="col-md-6">
            <h2 >Gynaecologist Consultation</h2>
            <div class="title-underline"></div>
            <h4 style="margin-top: 25px">Program name </h4>
            <p>Teleconsultation with a Gynaecologist on Pinky Promise. Please complete the payment and describe your issue in some detail so we can allocate the right doctor to you!</p>
            <h4>Program Description</h4>
            <p>Get a consultation, diagnosis and care in a highly private and friendly manner! Doctors will consult you on a phone call at a time that you prefer.</p>
            <h4>Fee breakup </h4>
            <p>Rs. 177/- inclusive of GST</p>
            <h4>Next steps</h4>
            <p>It will take us  a maximum of 12 working hours after receiving your payment to allocate a doctor to you. We work from 10am-8pm and do not work on Sundays or public holidays.</p>
            <p>We will ask you for a government issued ID proof to ensure your age is above 18 and your name matches what is entered by you here. This is required by law.</p>
            <h4>Refund and cancellation</h4>
            <p>Being disrespectful to team members will result in forfeiting your payment. We do not entertain refunds.</p>
            <h4>Name of the organizer </h4>
            <p>Pinky Promise</p>
            <p>Learn more: <a href="https://askpinkypromise.com" target="_blank">www.askpinkypromise.com</a></p>
            <h4>Contact Us:</h4>
            <p>Email: <a href="mailto:contact@askpinkypromise.com">contact@askpinkypromise.com</a></p>
            <p>Call: <a href="tel:02248903666">022-48903666</a></p>
            <p>Terms & Conditions:</p>
            <p><a href="https://askpinkypromise.com/terms-of-service/" target="_blank">www.askpinkypromise.com/terms-of-service/</a></p>
            <p>You agree to share information entered on this page with Pinky Promise Pvt Ltd (owner of this page) and Razorpay, adhering to applicable laws.</p>
            <p>Please note that as per the Medical Termination of Pregnancy Act 1971, Doctors on digital platforms like Pinky Promise cannot prescribe any medications for the termination of pregnancy. They can only counsel and guide you. By proceeding with an appointment, you acknowledge and understand this.</p>
         </div>
         <div class="col-md-6">
            <div class="card card-1" style="height: auto;    margin-left: 0px;">
                <div class="card-body">
                    <h4>Patient Information</h4>
                    <div class="title-underline"></div>
                     <form action="{{route('post.booking.detail')}}" method="POST" enctype="multipart/form-data" style="margin-top: 50px;" >
           
      <div  style="">
         
            
               <input type="hidden" name="services_id" value="{{$service_id}}">
                      <input type="hidden" name="date" value="{{$date}}">
                      <input type="hidden" name="time" value="{{$time}}">
                  <div class="row g-3">
                     <div class="form-group">
                        <label for="name" class="form-label">Name </label>
                        <div class="input-group">
                           <input type="text" class="form-control" name="name" id="name" value="" placeholder="Please Enter Full Name" required>
                        </div>
                        <span class="field-note">(Full name as in ID proof)</span>
                     </div>
                     <div class="form-group">
                        <label for="email" class="form-label">Email ID</label>
                        <div class="input-group">
                           <input type="email" class="form-control" name="email" id="email" value="" placeholder="" required >
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="phone" class="form-label">Phone</label>
                        <div class="input-group">
                           <input type="text" class="form-control" name="phone" id="phone" value="" placeholder="" onkeypress="return isNumber(event)" required>
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="dob" class="form-label">Date of Birth (DOB)</label>
                        <div class="input-group">
                           <input type="date" required class="form-control" name="dob" id="dob" value="" placeholder="">
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="form-label">Height</label>
                        <div class="input-group">
                           <input type="number" step="any" class="form-control" name="feet" id="feet" value="" required placeholder="feet">
                           <input type="number"  step="any" class="form-control" name="inches" id="inches" value="" required placeholder="inches">
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="form-label">Weight (in kg)</label>
                        <div class="input-group">
                           <input type="number" step="any" class="form-control" name="weight" id="weight" value="" required placeholder="">
                        </div>
                     </div>
                     <div class="form-group">                      
                        <label class="form-label">Last Menstrual Period</label>
                        <div class="input-group">
                           <input type="date" class="form-control" name="last_menstrual_period" required id="last_menstrual_period" value="" placeholder="">
                        </div>
                        <span class="field-note">When was the first day of the last time you had your periods?</span>
                     </div>
                     <div class="form-group">
                        <label for="problem_facing" class="form-label">Problem you are facing </label>
                        <div class="input-group">
                           <input type="text" class="form-control" required name="problem_facing" id="problem_facing" value="" placeholder="">
                        </div>
                        <span class="field-note">This will help the doctor to get a sense of the issue you want to speak to her about!</span>
                     </div>
                      <div class="form-group">
                        <label for="medical_history" class="form-label">Medical history</label>
                        <div class="input-group">
                           <textarea class="form-control" required name="medical_history" id="medical_history" value="" placeholder=""></textarea>
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="allergies" class="form-label">Allergies (optional)</label>
                        <div class="input-group">
                           <textarea class="form-control"   name="allergies" id="allergies" value="" placeholder=""></textarea>
                        </div>
                        <span class="field-note">Are you allergic to any foods or medicines?</span>
                     </div>
                     <div class="form-group">
                        <label for="thumbnail" class="form-label">Please upload Aadhar card, PAN card, Driving license, Voter ID or Passport</label>
                        <div class="input-group">
                           <input type="file" required class="form-control" name="thumbnail" id="thumbnail" accept="image/*" value="" placeholder="Upload valid ID Proof">
                        <span class="field-note">Why do we ask for ID?<br>According to the Indian Tele Medicine Practice Guidelines our doctors need to make sure that your name and date of brith matches a government ID before consulting with you. For more information on how we provide privacy to you and your data please read our privacy policy.</span>
                        </div>
                    
                     </div>
                     <div class="form-group">
                        <label for="upload" class="form-label">Medical Reports - max. 10 files (optional)</label>
                       
                        			<input type="file" class="form-control" id="upload" name="documents[]" multiple>
                        		
                            	<div class="files">
                            		<h6>Files Selected</h6>
                            		<ul></ul>
                            	</div>
                     </div>
                     
                  </div>
                  
              
           
      </div>
                        <script src="https://checkout.razorpay.com/v1/checkout.js"
                                data-key="{{env('RAZOR_KEY')}}"
                                data-amount="{{$setting->amount*100}}"
                                data-buttontext="Confirm Booking"
                                data-name="Pinky Promise"
                                data-description="Pinky Promise Tele Consult"
                                data-prefill.name="name"
                                data-prefill.email="email"
                                data-image="{{asset('public/logo.png')}}"
                                data-theme.color="#ff424c">
                        </script>
                        <input type="hidden" name="_token" value="{!!csrf_token()!!}">
                    </form>
            
         
                        
                        
      </div>
   </div>

</section>
@endsection
@section('footer')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script src="{{asset('public/js/script.js?v='.time())}}"></script>

<script type="text/javascript">
 
  $('#services').select2({
  selectOnClose: true
});
   function isNumber(evt) {
       evt = (evt) ? evt : window.event;
       var charCode = (evt.which) ? evt.which : evt.keyCode;
       if (charCode > 31 && (charCode < 48 || charCode > 57)) {
           return false;
       }
       return true;
   } 
    
   
  
</script>
@endsection